version_flag = "v0.0.6"

from scripts.faceswap_logging import logger

logger.info(f"FaceSwap {version_flag}")
